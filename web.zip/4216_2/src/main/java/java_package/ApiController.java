/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_package;

import com.google.gson.Gson;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.bind.annotation.PathVariable;

/**
 *
 * @author mansumchiu
 */

@RestController
@RequestMapping(path="/api")   
public class ApiController {
     private static final Logger log = LoggerFactory.getLogger(ApiController.class);
     private static final String flight_key = "5d54da-52c9a3";
     private static final String traffic_key = "AIzaSyDsrUXQGYKtvZJn-qBw_ya59Hl_V4Yzp4E";
     

    @Autowired
    Gson gson;
    
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    @Autowired
    RestTemplate restTemplate;
          
    @GetMapping("/flights")
    public String getflights() throws Exception{
            String URL = "http://aviation-edge.com/v2/public/timetable?key=" + flight_key + "&iataCode=HKG&type=departure";
            String response = restTemplate.getForObject(URL, String.class);
            String result = converting(response);
        return result;
    }
    
    @GetMapping("/traffic/{origin}/{dest}")
    public String gettraffic(@PathVariable String origin, @PathVariable String dest){
            String URL = "https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=" + origin + ",HK&destinations=" + dest + ",HK&key="
                     + traffic_key;
             String result = restTemplate.getForObject(URL, String.class);
              
       return result;
    }
    
    private String converting (String input) throws Exception{
        FlightToVue.Flights[] flightsArray = gson.fromJson(input, FlightToVue.Flights[].class);
        List<FlightToVue.Vue> vueList = new ArrayList<>();
        Date currentTime = new Date();
        SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-ddHH:mm:ss.SSS");        
        FlightToVue x = new FlightToVue();
        System.out.println(flightsArray[180].flight.iataNumber);
        
        for (int i = 0; i < flightsArray.length; i++) {

            String scheduledString = flightsArray[i].departure.scheduledTime;
            
            Date scheduledDate = new Date();
            if(flightsArray[i].departure.scheduledTime != null){
                scheduledString = scheduledString.replace("T","");
                scheduledDate = formatter.parse(scheduledString);
            }
            
            if (flightsArray[i].departure.estimatedTime != null) {
                
                String estimatedString = flightsArray[i].departure.estimatedTime;
                estimatedString = estimatedString.replace("T","");
                Date estimatedDate = formatter.parse(estimatedString);
                if (currentTime.compareTo(estimatedDate) <= 0) {
                    //scheduledTime is greater
                    FlightToVue.Vue temp = x.new Vue(flightsArray[i]);
                    vueList.add(temp);
                }
            } else {
                if (currentTime.compareTo(scheduledDate) <= 0) {
                    //scheduledTime is greater
                    FlightToVue.Vue temp = x.new Vue(flightsArray[i]);
                    vueList.add(temp);
                }
            }
        }
        String result = gson.toJson(vueList);
        return result;
    }
    

}
