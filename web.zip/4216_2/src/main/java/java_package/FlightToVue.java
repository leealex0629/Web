/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_package;

import com.google.gson.Gson;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.bind.annotation.PathVariable;

/**
 *
 * @author ppcha
 */

public class FlightToVue {
    class Flights{
        String status;
        Departure departure;
        Arrival arrival;
        Airline airline;
        Flight flight;
    }
    class Departure{
        String terminal;
        String delay;
        String scheduledTime;
        String estimatedTime;
    }
    
    class Arrival{
        String iataCode;
    }
    
    class Airline{
        String name;
    }
    
    class Flight{
        String iataNumber;
    }
    
    class Vue{
        String status;
        String terminal;
        String delay;
        String scheduledTime;
        String estimatedTime;
        String iataCode;
        String name;
        String iataNumber;
        String time;
        public Vue (Flights flights){
            this.status = flights.status;
            this.terminal = flights.departure.terminal;
            if(flights.departure.delay == null){
                this.delay = "On Time";
            } else {
                this.delay = "Delay: " + flights.departure.delay + "mins";
            }
            this.scheduledTime = flights.departure.scheduledTime;
            this.estimatedTime = flights.departure.estimatedTime;
            this.iataCode = flights.arrival.iataCode;
            this.name = flights.airline.name;
            this.iataNumber = flights.flight.iataNumber;
            if(this.estimatedTime != null){
                this.time = this.estimatedTime.replace("T", " ");
            } else {
                this.time = this.scheduledTime.replace("T", " ");
            }
        }
    }
}
    
