/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_package;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author mansumchiu
 */

@SpringBootApplication
public class WebApp {
    public static void main(String[] args) {
		SpringApplication.run(WebApp.class, args);
	}
    
   @Bean
   public RestTemplate getRestTemplate() {
      return new RestTemplate();
   }
}
