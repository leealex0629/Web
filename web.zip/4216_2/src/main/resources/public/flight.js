
Vue.filter('numeral', function (value) {
  return numeral(value).format('0,0');
})

new Vue({
  el: '#app',
  data: {
    searchItem: '',
    items: [],
    filteredItems: [],
    paginatedItems: [],
    selectedItems: [],
    pagination: {
      range: 5,
      currentPage: 1,
      itemPerPage: 8,
      items: [],
      filteredItems: [],
    }
  },
  mounted: function () {
      
    var temp = localStorage.getItem("flight_timetable");
    var JsonObj = JSON.parse(temp);
    this.items = JsonObj;              
    console.log(this.items);

    this.filteredItems = this.items
                   this.buildPagination()
                   this.selectPage(1)  

  this.intervalid1 = setInterval(() => {
    fetch('http://localhost/api/flights')
      .then((response) => {
      return response.json();
    })
    .then((flights) => {
              var temp = JSON.parse(flights); 
              this.items = temp;              
              //console.log(this.items);

              this.filteredItems = this.items
                 this.buildPagination()
                 this.selectPage(1)    
                  this.searchInTheList(this.searchItem);
                  localStorage.setItem("flight_timetable",flights);
    })

     }, 30000);

},

  methods: {
    clearSearchItem(){
      this.searchItem = undefined
      this.searchInTheList('')
    },
    searchInTheList(searchText, currentPage){
      if(_.isUndefined(searchText)){
        this.filteredItems = _.filter(this.items, function(v, k){
          return !v.selected
        })
      }
      else{
        this.filteredItems = _.filter(this.items, function(v, k){
          return !v.selected && v.iataNumber.toLowerCase().indexOf(searchText.toLowerCase()) > -1
        })
      }
      this.filteredItems.forEach(function(v, k){
        v.key = k+1
      })  
      this.buildPagination()
      
      if(_.isUndefined(currentPage)){
        this.selectPage(1) 
      }
      else{
        this.selectPage(currentPage) 
      }
    },
    buildPagination(){
      let numberOfPage = Math.ceil(this.filteredItems.length/this.pagination.itemPerPage)
      this.pagination.items = []
      for(var i=0; i<numberOfPage; i++){
        this.pagination.items.push(i+1)
      }
    },
    selectPage(item) {
      if(item < 1){
         this.pagination.currentPage = 1
      }else if(item > this.pagination.items.length){
        this.pagination.currentPage = this.pagination.items.length
      }else{
         this.pagination.currentPage = item
    }  
      let start = 0
      let end = 0
      if(this.pagination.currentPage < this.pagination.range-2){
        start = 1
        end = start+this.pagination.range-1
      }
      else if(this.pagination.currentPage <= this.pagination.items.length && this.pagination.currentPage > this.pagination.items.length - this.pagination.range + 2){
        start = this.pagination.items.length-this.pagination.range+1
        end = this.pagination.items.length
      }
      else{
        start = this.pagination.currentPage-2
        end = this.pagination.currentPage+2
      }
      if(start<1){
        start = 1
      }
      if(end>this.pagination.items.length){
        end = this.pagination.items.length
      }
      
      this.pagination.filteredItems = []
      for(var i=start; i<=end; i++){
        this.pagination.filteredItems.push(i);
      }
      
      this.paginatedItems = this.filteredItems.filter((v, k) => {
        return Math.ceil((k+1) / this.pagination.itemPerPage) == this.pagination.currentPage
      })
      console.log(this.pagination.currentPage);
    },
    selectItem(item){
      item.selected = true
      localStorage.setItem('storedFlightno', item.iataNumber);
      localStorage.setItem("storedDepartTime", item.time);
      location.href = "result.html"
    },    
    removeSelectedItem(item,index){
      item.selected = false
      this.selectedItems.splice(index,1)
      this.searchInTheList(this.searchItem, this.pagination.currentPage)
    }
  }
})


