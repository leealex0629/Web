var geocode_API_key = "AIzaSyBWkD5EpwTX6_nEt9UKMS4XrlFrBIcA_ZY";

var latitude;
var longitude;

var currentlat;
var currentlng;

/*
window.onload = loadpage;

function loadpage(){
    console.log('load');
    getLocation();
    getflight();
}*/

function getLocation(){
    getflight();
    console.log('get');
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(myMap);
    } else {
        console.log("get location failed");
        myMap();
    }
}

function getflight(){
    fetch('http://localhost/api/flights')
  .then(function(response) {
    return response.json();
  })
  .then(function(myJson) {
    //console.log(myJson);
    localStorage.setItem("flight_timetable", myJson);;
  });
}

function myMap(position) {
    currentlat = position.coords.latitude;
    currentlng = position.coords.longitude;

    latitude = position.coords.latitude;
    longitude = position.coords.longitude;
    //var myLatLng = {lat: latitude, lng: longitude};
    var mapProp = {
        center:new google.maps.LatLng(latitude ,longitude),
        zoom:15,
        disableDoubleClickZoom: true
    };
    var directionsService = new google.maps.DirectionsService;
    var directionsDisplay = new google.maps.DirectionsRenderer;

    var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
    directionsDisplay.setMap(map);
    
    
    
    /*
    var marker = new google.maps.Marker({
        position: myLatLng,
        map: map,
        draggable:true,
        title: 'Current Location'
    });*/
    onChangeHandler = function() {
        calcRoute(directionsService, directionsDisplay);
        //marker.remove();
    };
    getgeoname();
    var drive = document.getElementById('DRIVING');
    drive.onclick = function () {
        onChangeHandler();
    };
    var bus = document.getElementById('BUS');
    bus.onclick = function () {
        onChangeHandler();
    };
    var rail = document.getElementById('RAIL');
    rail.onclick = function () {
        onChangeHandler();
    };
    
    document.getElementById("startpoint").onchange = function(){
        onChangeHandler();
    };

    

    google.maps.event.addListener(map, 'dblclick', function(e) {
        //var positionDoubleclick = e.latLng;
        //marker.setPosition(positionDoubleclick);
        // if you don't do this, the map will zoom in
        latitude = e.latLng.lat();
        longitude = e.latLng.lng();
        getgeoname();

    });
    
    document.getElementById("currentlocation").onclick = function(){
        latitude = currentlat;
        longitude = currentlng;
        getgeoname();
    };
    
}

function calcRoute(directionsService, directionsDisplay){
    var start = document.getElementById('startpoint').value;
    var end = "Hong Kong International Airport,Hong Kong";
    var travelMode;
    var request;
    if (document.getElementById('DRIVING').checked)
    {
        travelMode = document.getElementById('DRIVING').value;
        request = {
            origin: start,
            destination: end,
            travelMode: travelMode
        };
    }
    if (document.getElementById('BUS').checked)
    {
		request = {
            origin: start,
            destination: end,
            travelMode: 'TRANSIT',
            transitOptions : {modes:['BUS']}
        };
    }
	if (document.getElementById('RAIL').checked)
    {
		request = {
            origin: start,
            destination: end,
            travelMode: 'TRANSIT',
            transitOptions : {modes:['RAIL']}
        };
    }
    directionsService.route(request, function(response, status) {
        if (status === "OK") {
            directionsDisplay.setDirections(response);
        }
    });
	
}

function getgeoname(){
    console.log('getgeoname');
    fetch('https://maps.googleapis.com/maps/api/geocode/json?latlng=' + latitude + ',' + longitude + '&key=' + geocode_API_key)
  .then(function(response) {
    return response.json();
  })
  .then(function(myJson) {
    //console.log(myJson);
    document.getElementById("startpoint").value = myJson.results[0].formatted_address;
    onChangeHandler();
  });
}

//whats this
/*
function getgeocode(address){
    address = address.replaceAll(" ", "");
    fetch('https://maps.googleapis.com/maps/api/geocode/json?address=' + address + '&key=' + geocode_API_key)
  .then(function(response) {
    return response.json();
  })
  .then(function(myJson) {
    var latlng = new google.maps.LatLng(myJson.results[0].geometry.location.lat, myJson.results[0].geometry.location.lng);
    latitude = myJson.results[0].geometry.location.lat;
    longitude = myJson.results[0].geometry.location.lng;
    console.log(myJson);
    console.log(myJson.results[0].geometry.location.lat , myJson.results[0].geometry.location.lng);
  });
}
*/




document.getElementById("gotoResult").onclick = function(){
    var start = document.getElementById("startpoint").value;
    var flightno = document.getElementById("flightno").value;
    var test = flightno.toUpperCase();
    var found = false;
    var time;
    
    var temp = localStorage.getItem("flight_timetable");
    var JsonObj = JSON.parse(temp);

    for(var item in JsonObj){
        if(JsonObj[item].iataNumber == test){
            time = JsonObj[item].time;
            
            found = true;
        }
    }

    localStorage.setItem("storedLocation",start);
    localStorage.setItem("storedFlightno",flightno);
    localStorage.setItem("storedDepartTime", time);

    if(start.length == 0 || flightno.length == 0){
        alert("Start location and Flight number cannot be empty!");
    }
    
    if(start.length != 0 && flightno.length != 0 && found){
        location.href = "result.html";
    }else if (flightno.length != 0 && !found){
        alert("flight number not found!");
    }
};