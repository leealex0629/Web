var geocode_API_key = "AIzaSyBWkD5EpwTX6_nEt9UKMS4XrlFrBIcA_ZY";

var latitude;
var longitude;

var minNeed;
var departureTime = localStorage.getItem("storedDepartTime");
var startTime;
var checkInMin = 45;

/*
window.onload = function(){
    console.log('loadpage');
    getLocation();
};
*/
function getLocation(){

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(myMap);
    } else {
        console.log("get location failed");
    }
}


function myMap(position) {

    
    latitude = position.coords.latitude;
    longitude = position.coords.longitude;
    //var myLatLng = {lat: latitude, lng: longitude};
    var mapProp = {
        center: {lat: 22.28552, lng: 114.15769},
        zoom: 15,
        disableDoubleClickZoom: true
    };
    var directionsService = new google.maps.DirectionsService;
    var directionsDisplay = new google.maps.DirectionsRenderer;
    var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
    
    directionsDisplay.setMap(map);
    
    directionsDisplay.setPanel(document.getElementById('panel'));

    
    /*
    var marker = new google.maps.Marker({
        position: myLatLng,
        map: map,
        draggable:true,
        title: 'Current Location'
    });*/
    onChangeHandler = function() {

        calcRoute(directionsService, directionsDisplay);
        
        //marker.remove();
    };
    
    var drive = document.getElementById('DRIVING');
    drive.onclick = function () {
        onChangeHandler();
    };
    var bus = document.getElementById('BUS');
    bus.onclick = function () {
        onChangeHandler();
    };
    var rail = document.getElementById('RAIL');
    rail.onclick = function () {
        onChangeHandler();
    };
    
    google.maps.event.addListener(map, 'dblclick', function(e) {
        //var positionDoubleclick = e.latLng;
        //marker.setPosition(positionDoubleclick);
        // if you don't do this, the map will zoom in
        latitude = e.latLng.lat();
        longitude = e.latLng.lng();
        getgeoname();

    });
   
    onChangeHandler();
}

function getgeoname(){
    console.log('getgeoname');
    fetch('https://maps.googleapis.com/maps/api/geocode/json?latlng=' + latitude + ',' + longitude + '&key=' + geocode_API_key)
  .then(function(response) {
    return response.json();
  })
  .then(function(myJson) {
    //console.log(myJson);
    localStorage.setItem("storedLocation", myJson.results[0].formatted_address);
    onChangeHandler();
  });
}

function calcRoute(directionsService, directionsDisplay){
    var start = localStorage.getItem("storedLocation");
    var end = "Hong Kong International Airport,Hong Kong";
    var travelMode;
    var request;
    if (document.getElementById('DRIVING').checked)
    {
        travelMode = document.getElementById('DRIVING').value;
        request = {
            origin: start,
            destination: end,
            travelMode: travelMode
        };
    }
    if (document.getElementById('BUS').checked)
    {
		request = {
            origin: start,
            destination: end,
            travelMode: 'TRANSIT',
            transitOptions : {modes:['BUS']}
        };
    }
	if (document.getElementById('RAIL').checked)
    {
		request = {
            origin: start,
            destination: end,
            travelMode: 'TRANSIT',
            transitOptions : {modes:['RAIL']}
        };
    }
    directionsService.route(request, function(response, status) {
        if (status === "OK") {
            directionsDisplay.setDirections(response);
            minNeed = response.routes[0].legs[0].duration.value/60;
            calTime();
        }
    });

}

function calTime(){
    var current = new Date();
    var date = new Date(departureTime);
    date.setMinutes(date.getMinutes() - minNeed - checkInMin);
    var day = date.getMonth() + 1;
    var resultString;
    if(current < date){
        resultString = 'You Should leave home by ' + date.getDate() + '/' + day + ' ' + date.getHours() + ':' + date.getMinutes();
    }else{
        var temp = minNeed + checkInMin;
        temp = Number(temp).toFixed(2);
        resultString = 'You are already too late, this takes you ' + temp + ' mins';
    }
    document.getElementById('departtime').innerHTML = resultString;
}




/*
function getgeoname(){
    console.log("geoname");
    fetch('https://maps.googleapis.com/maps/api/geocode/json?latlng=' + latitude + ',' + longitude + '&key=' + geocode_API_key)
  .then(function(response) {
    return response.json();
  })
  .then(function(myJson) {
    console.log(myJson);
    onChangeHandler();
  });
}
**/

/*
function getgeocode(address){
    //address = address.replaceAll(" ", "");
    fetch('https://maps.googleapis.com/maps/api/geocode/json?address=' + address + '&key=' + geocode_API_key)
  .then(function(response) {
    return response.json();
  })
  .then(function(myJson) {
    var latlng = new google.maps.LatLng(myJson.results[0].geometry.location.lat, myJson.results[0].geometry.location.lng);
    latitude = myJson.results[0].geometry.location.lat;
    longitude = myJson.results[0].geometry.location.lng;
    console.log(myJson);
    console.log(myJson.results[0].geometry.location.lat , myJson.results[0].geometry.location.lng);
  });
}
*/